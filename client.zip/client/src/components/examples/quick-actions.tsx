import { QuickActions } from "../quick-actions";

export default function QuickActionsExample() {
  return (
    <div className="p-6 max-w-sm">
      <QuickActions />
    </div>
  );
}
