import { RevenueCalculator } from "../revenue-calculator";

export default function RevenueCalculatorExample() {
  return (
    <div className="p-6 max-w-md">
      <RevenueCalculator />
    </div>
  );
}
