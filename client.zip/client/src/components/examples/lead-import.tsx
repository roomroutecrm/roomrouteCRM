import { LeadImport } from "../lead-import";

export default function LeadImportExample() {
  return (
    <div className="p-6 max-w-2xl">
      <LeadImport />
    </div>
  );
}
